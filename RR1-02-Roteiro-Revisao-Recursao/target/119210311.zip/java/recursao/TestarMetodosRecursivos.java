package recursao;

public class TestarMetodosRecursivos {
	public static void main(String[] args) {
	}
}
